# Getting this onto `IAmSaxena28/WORKFLOW-AUTOMATION`

Your repo already has content in it — so we're **adding the labs as a subfolder** (`camunda-workflow-labs/`) with one new commit, not replacing anything. Everything you already have stays exactly as it is.

**Never hand your password (or a permanent token) to any chat or tool.** The flow below keeps your credentials on your machine; the only step that touches a token is the final push, and it happens in *your* terminal, typed hidden.

### 1 · Make a Personal Access Token (1 minute)

- GitHub → Settings → **Developer settings → Personal access tokens**
  - *Tokens (classic)* → **Generate new** → scope just **`repo`** (write access to your repos; classic is simplest) — or
  - *Fine-grained* → create one, owner = your account, repo = `WORKFLOW-AUTOMATION`, permission **Contents: Read and write**, expiration **1 hour** (even better — it dies when you're done).
- Copy it; GitHub shows it once.

### 2 · Push the labs subfolder (30 seconds)

```bash
cd camunda-workflow-labs
./push-to-github.sh
```

That's it — the script uses your repo as the default (`IAmSaxena28/WORKFLOW-AUTOMATION`, subfolder `camunda-workflow-labs`). It will:

1. clone your existing repo,
2. copy the lab files into `camunda-workflow-labs/` inside it,
3. refuse to stage anything that looks like a secret,
4. commit *"Add Camunda 8 PBJ-2 Labs 1-3 …"*,
5. ask for your token once (hidden input) and push to your default branch (`main` or `master`, auto-detected).

If you want a different subfolder name or user, the args are: `./push-to-github.sh <username> <repo> <subfolder>`.

### 3 · Post-push

- Open `https://github.com/IAmSaxena28/WORKFLOW-AUTOMATION` → the `camunda-workflow-labs/` folder should render the README, models, and worker code; your pre-existing files are untouched.
- Put your name/team in the `*your name here*` placeholders (root README, each lab README).

### Then the run evidence (do this after the labs are run)

Run the labs per the root README + each lab README, drop screenshots into `models/<lab>/screenshots/`, and add them in one more commit — e.g. clone your repo locally and:

```bash
git add camunda-workflow-labs/models
git commit -m "Add Tasklist/Operate run evidence (screenshots)"
git push
```

### What the grader will look for (checklist mapping)

| Assignment checklist item | Where it lives |
|---|---|
| BPMN model files + design screenshots | `camunda-workflow-labs/models/<lab>/*.bpmn` + `screenshots/01-*.png` |
| DMN model files + rules + sample results | `models/<lab>/*.dmn` + each lab README §2 |
| Worker source + run instructions | `worker/` + root README §3–4 + each lab README §7 |
| REST connector config + API examples | each lab README §4 + `docs/rest-connectors-and-tunnel.md` |
| Process variable dictionary (name/type/purpose) | each lab README §3 + `docs/process-variable-dictionary.md` |
| Test cases: expected vs actual, all four path types | each lab README §5 (fill *Actual/Status* after your run) |
| Deployment + execution evidence | `screenshots/03,04-*` (Tasklist/Operate) |
| Tasklist evidence for human tasks | `screenshots/05-*` |
| Operate evidence incl. incident resolution | `screenshots/06,07-*` + each lab README §6 |
| Short report (architecture, flow, results, limitations) | each lab README §8 + root README "Design notes" |
