package com.pbj.camunda.mock;

import org.springframework.stereotype.Component;

/**
 * In-memory failure switch shared by the mock REST services AND the external job workers.
 *
 * This is the single mechanism used in all three labs to demonstrate the
 * "intentional failure -> Operate incident -> fix root cause -> retry" exercise:
 *
 *   POST /mock/failure/enable   -> mock endpoints answer HTTP 500 and the
 *                                  workers refuse to complete their job,
 *                                  so the running instances create incidents.
 *   GET  /mock/failure/status  -> current state
 *   POST /mock/failure/disable -> services recover; the incident can now be
 *                                  retried in Operate and the instance completes.
 *
 * The flag is app-side state (not a process variable) on purpose: after the
 * cause is fixed, retrying the SAME job in Operate succeeds, which is exactly
 * the recovery story the assignment asks for.
 */
@Component
public class MockState {

    private final java.util.concurrent.atomic.AtomicBoolean failureEnabled =
            new java.util.concurrent.atomic.AtomicBoolean(false);

    public boolean isFailureEnabled() {
        return failureEnabled.get();
    }

    public boolean setFailureEnabled(boolean enabled) {
        return failureEnabled.updateAndGet(current -> current || enabled);
    }

    public boolean clearFailure() {
        return failureEnabled.getAndSet(false);
    }
}
