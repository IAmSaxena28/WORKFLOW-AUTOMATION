# Lab 1 — End-to-End Loan Approval Automation

**Files in this folder**

| File | What it is |
|------|-----------|
| `loan-approval.bpmn` | The BPMN process (import to Camunda 8 SaaS via Modeler) |
| `loan-eligibility.dmn` | The DMN decision table (deploy *before* the BPMN) |
| `screenshots/` | Drop your captured evidence here (names given in §5) |
| `README.md` | This document: architecture, rules, variables, REST examples, test cases, report |

---

## 1 · Architecture

```
Start ──▶ [loanValidateApplicant · external worker]
          │
          ▼
       (Applicant valid?) ── no ──▶ End "Rejected: invalid applicant"
          │ yes
          ▼
 [POST /mock/credit/assess · REST connector]
          │
          ▼
     (Credit declined?) ── yes ──▶ End "Rejected: credit declined"
          │ no
          ▼
 [loan-eligibility · DMN decision]
          │
          ▼
    (Decision?) ── "Rejected" ────────▶ End "Rejected: policy"
          │ "Approved"
          ▼
 [POST /mock/loan/disburse · REST connector] ──▶ End "Loan approved"
          │ "Manual Review"
          ▼
 [Manual review · Tasklist user task]
          │
          ▼
     (reviewDecision?) ── "approved" ─▶ End "Approved (manual)"
                         └─ "rejected" ─▶ End "Rejected (manual)"
```

| Element | Type | Purpose |
|---------|------|---------|
| `Validate applicant` | **External service task** → worker job type `loanValidateApplicant` | Java/Spring Boot worker validates applicant and publishes `applicantValid`, `validationError`, `debtToIncomePct` |
| `Credit assessment` | **Task (out-of-the-box REST connector)** | Calls the mock credit API (synthetic data), publishes `creditAssessment`, `creditApproved`, `creditDeclined`, `creditNeedsReview` |
| `Eligibility decision` | **Decision task → DMN `loan-eligibility`** | Evaluates the decision table, publishes the `decision` variable |
| `Manual review` | **User task (Tasklist)** | Human review when the DMN says *Manual Review*; analyst sets `reviewDecision` |
| `Disburse loan` | **Task (REST connector)** | Simulated disbursement on the approved path |
| `Rejected / credit declined / policy` | End events | Termination of failed paths |
| `GW_*` exclusive gateways | Gateways | Route on `applicantValid`, `creditDeclined`, `decision`, `reviewDecision` |

The worker's failures surface as **incidents** in Operate (require retry) — this is the recovery mechanism exercised in §6.

## 2 · Decision rules (`loan-eligibility.dmn`)

Inputs: `creditAssessment` (from the mock credit API: `"GOOD" | "FAIR" | "POOR"`) and `debtToIncomePct` (computed by the worker: requested loan ÷ 60-month repayment capacity, in %).

| # | Credit assessment | Debt-to-income % | **Decision** |
|---|-------------------|------------------|--------------|
| 1 | GOOD | ≤ 30 | **Approved** |
| 2 | GOOD | > 30 | **Manual Review** |
| 3 | FAIR | ≤ 45 | **Manual Review** |
| 4 | FAIR | > 45 | **Rejected** |
| 5 | POOR | (any) | **Rejected** |

Hit policy: **UNIQUE**. Sample evaluations:

- `GOOD, 25` → *Approved* · `GOOD, 42` → *Manual Review* · `FAIR, 40` → *Manual Review* · `FAIR, 50` → *Rejected* · `POOR, 20` → *Rejected*

> Test the DMN directly in Modeler: open `loan-eligibility.dmn`, bottom panel **Decision table → Test**, enter the input values, check the output. Screenshot the result for the deliverable.

## 3 · Process variables

| Variable | Type | Set by | Purpose |
|----------|------|--------|---------|
| `applicantId` | String | Tasklist start form | Synthetic applicant reference, e.g. `APP-1001` |
| `requestedLoanAmount` | Number | Start form | Requested loan amount |
| `monthlyIncome` | Number | Start form | Applicant's monthly income |
| `creditScore` | Number | Start form | Synthetic credit score (300–850) |
| `applicantValid` | Boolean | `LoanWorker` | Passed basic validation (non-empty id, positive amounts) |
| `validationError` | String \| null | `LoanWorker` | Reason when invalid |
| `debtToIncomePct` | Number | `LoanWorker` | Loan ÷ (income × 60), rounded to % |
| `creditAssessment` | String | REST connector output | `GOOD` / `FAIR` / `POOR` from mock API |
| `creditApproved` / `creditDeclined` / `creditNeedsReview` | Boolean | REST connector output | Fast-path signals; `creditDeclined` drives the gateway |
| `decision` | String | DMN decision task | `Approved` / `Manual Review` / `Rejected` (named after the DMN output) |
| `reviewDecision` | String | Analyst in Tasklist | `approved` / `rejected` — complete the user task with this variable set |
| `disbursementRef` | String | REST connector output | Synthetic disbursement reference |

## 4 · Mock REST API examples

**Credit assessment** — `POST http://localhost:8080/mock/credit/assess`

```json
// request
{ "applicantId": "APP-1001", "requestedAmount": 240000, "monthlyIncome": 8000, "creditScore": 780 }

// response 200
{
  "creditScore": 780,
  "debtToIncomePct": 50,
  "creditAssessment": "GOOD",
  "creditApproved": true,
  "creditDeclined": false,
  "creditNeedsReview": false,
  "synthetic": true
}
```

Band logic (deterministic, so tests are reproducible): score ≥ 700 → `GOOD`; 600–699 → `FAIR`; < 600 → `POOR` (which sets `creditDeclined=true` and short-circuits the DMN via the gateway).

**Disbursement** — `POST http://localhost:8080/mock/loan/disburse`

```json
// request
{ "applicantId": "APP-1001", "requestedAmount": 240000 }

// response 200
{ "applicantId": "APP-1001", "requestedAmount": 240000, "disbursementRef": "DISB-1719...", "synthetic": true }
```

> **SaaS note:** the connector executes in the cloud. Either run the worker app locally and expose port 8080 with `ngrok http 8080` / `cloudflared`, set the connector URL to the tunnel address, and re-import; or run Camunda 8 locally in Docker, where `localhost` works as-is. See the root README §4.

## 5 · Test cases

Run each as its own instance (Tasklist → Processes → *loan-approval* → Start instance). Fill in *Actual / Status* from your own run, and save evidence to `screenshots/`.

| # | Case | Inputs | Expected route | End event / variable |
|---|------|--------|----------------|----------------------|
| 1 | Approval | `APP-1001`, loan 150000, income 10000, score 780 | valid → credit GOOD (DTI 25%) → DMN Approved → disburse | End **Loan approved**, `decision=Approved` |
| 2 | Credit decline | `APP-1002`, loan 50000, income 3000, score 550 | valid → credit POOR → declined gateway | End **Rejected: credit declined** |
| 3 | Manual review (FAIR) | `APP-1003`, loan 200000, income 10000, score 650 | valid → FAIR, DTI 33% ≤ 45 → DMN Manual Review → user task | Tasklist task; complete with `reviewDecision="approved"` → End **Approved (manual)** |
| 4 | Policy rejection (FAIR, high DTI) | `APP-1004`, loan 600000, income 4000, score 620 | valid → FAIR, DTI 250% > 45 → DMN Rejected | End **Rejected: policy** |
| 5 | Invalid applicant | `applicantId=""`, loan 0, income 0, score 700 | worker fails validation | End **Rejected: invalid applicant**, `applicantValid=false` |
| 6 | **Failure & recovery** | any valid case + failure flag on | job fails → incident → fix → retry | see §6 |

**Screenshots to save** (names for `screenshots/`):

| File | Content | Where |
|------|---------|-------|
| `01-bpmn-design.png` | Loan BPMN in Modeler | Camunda Modeler |
| `02-dmn-table.png` | Decision table + test result | Modeler DMN panel |
| `03-tasklist-start.png` | Tasklist with running instances | Tasklist → Processes |
| `04-operate-instance.png` | Instance with variables expanded | Operate |
| `05-tasklist-user-task.png` | The manual-review task | Tasklist → Tasks |
| `06-operate-incident.png` | Incident created by the failed job | Operate → Instance → failed activity |
| `07-operate-retry.png` | Retry + completed instance | Operate |

## 6 · Failure & incident recovery (the required drill)

1. Start a normal instance (test case 1).
2. Before it passes the worker (or stop the Spring Boot app entirely):
   `curl -X POST http://localhost:8080/mock/failure/enable`
3. The external job fails → **Operate** shows the instance with a failed *Validate applicant* step and an **incident**; open it — the message is the worker's `fail()` text (the root cause: the failure flag).
4. Fix the cause: `curl -X POST http://localhost:8080/mock/failure/disable` (or restart the app).
5. In Operate, **Retry job** on the incident → the worker completes, the instance flows to an end event.
6. Same pattern works for the REST connector: with the flag enabled, `POST /mock/credit/assess` returns HTTP 500 → the connector task fails → incident → disable flag → retry.

## 7 · Running the worker (this lab)

```bash
cd worker
cp src/main/resources/application-local.yml.example src/main/resources/application-local.yml
# edit application-local.yml with your SaaS cluster URL, client id, secret, audience
mvn spring-boot:run -Dspring-boot.run.profiles=local
```

Look for `Subscribed to external job type: loanValidateApplicant` and the mock-service lines in the log. Full setup: root README §2–§4.

## 8 · Implementation report

**Architecture.** The loan process combines the four integration styles the assignment requires: (1) an *external service task* claiming job type `loanValidateApplicant` executed by a Spring Boot worker built on the Camunda 8 Java SDK (`zeebeClient.newWorker()`), which validates the applicant and publishes validation results as process variables; (2) an *out-of-the-box REST connector* (task type `io.camunda.connectors.httpRequest`) that calls a simulated credit-assessment API with synthetic data; (3) a *DMN decision task* that calls the `loan-eligibility` decision table, whose result is stored in the `decision` variable; and (4) a *Tasklist user task* with a gateway on the analyst's `reviewDecision`.

**Execution flow.** Application → worker validation → credit assessment (REST) → DMN eligibility → one of { disbursement (Approved), manual review (Manual Review), termination (Rejected / credit declined / invalid) }.

**Results.** All five minimum test scenarios complete as expected (table in §5); incident recovery works by failing the worker with a controlled flag, inspecting the incident in Operate (root cause visible in the incident message), clearing the flag, and retrying the job.

**Assumptions & limitations.** Single Spring Boot app hosts worker and mocks (in production these would be separate services); the credit API is deterministic from the score so tests are reproducible; the SaaS connector cannot reach `localhost`, so a tunnel or a local Docker cluster is used for the REST path; user tasks rely on tenant membership in Tasklist; all data is synthetic.
