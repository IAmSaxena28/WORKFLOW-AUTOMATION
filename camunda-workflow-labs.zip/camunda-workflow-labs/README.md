# Camunda 8 — End-to-End Workflow Automation (Labs 1–3)

**PBJ-2 Practical Assignment** · Team / Student: *your name here* · Camunda 8 SaaS · BPMN + DMN + Java/Spring Boot

This repository contains three complete, runnable workflow implementations on Camunda 8:

| Lab | Scenario | DMN decision | External worker job type | Mock API |
|-----|----------|--------------|--------------------------|----------|
| 1 | [Loan approval](models/lab1-loan-approval/) | `loan-eligibility` — Approved / Rejected / Manual Review | `loanValidateApplicant` | `POST /mock/credit/assess` |
| 2 | [E-commerce order fulfilment](models/lab2-ecommerce/) | `order-priority` — HIGH / NORMAL / LOW | `orderValidateAndPrice` | `POST /mock/payment/charge` |
| 3 | [Hospital appointment & triage](models/lab3-hospital/) | `patient-triage` — Routine / Priority Review / Urgent Assessment | `registrationValidate` | `POST /mock/scheduling/slots` |

Each lab pairs a **BPMN process** (orchestration, gateways, Tasklist user task, incident path) with a **DMN decision table** (documented business rules), a **Spring Boot external job worker** (business validation + job completion), and a **mock REST API** driven by the BPMN **REST Connector** — so every path required by the assignment is covered: normal flow, rejection, manual review, service failure, and incident recovery.

---

## Architecture (all three labs)

```
 Camunda Modeler                Camunda 8 SaaS                     This repo (worker + mock API)
 ┌───────────────┐   import   ┌──────────────────────────┐        ┌────────────────────────────┐
 │ loan-approval │ ──────────▶│  BPMN runtime + Operate   │◀───── │  Spring Boot app :8080     │
 │  .bpmn        │           │                           │ job   │  ┌──────────────────────┐  │
 │ loan-         │           │  DMN engine               │──────▶│  │ external job worker  │  │
 │  eligibility  │ ─────────▶│  evaluates DMN on request │      │  │ (camunda-java-client)│  │
 │  .dmn         │  deploy   │                           │      │  └──────────────────────┘  │
 └───────────────┘           │  Tasklist: user tasks     │      │  ┌──────────────────────┐  │
                             │                           │      │  │ mock REST services   │  │
                             │  Connectors call out ─────┼─────▶│  │ /mock/credit …       │  │
                             └──────────────────────────┘ REST │  └──────────────────────┘  │
                                                               └────────────────────────────┘
```

- **External service task** → claimed by the Spring Boot worker via the Java SDK (long-polling).
- **Task (Connector)** → Camunda SaaS executes the REST call itself; no worker needed.
- **User task** → human review in **Tasklist**.
- **Monitor / recovery** → **Operate** shows instances, variables, incidents; failed jobs show up as incidents which can be retried after fixing the root cause.

All test data is **synthetic**. No real payment credentials, PII, or patient data exist in this repository.

---

## Repository layout

```
├── models/
│   ├── lab1-loan-approval/      loan-approval.bpmn · loan-eligibility.dmn · README + screenshots/
│   ├── lab2-ecommerce/          order-processing.bpmn · order-priority.dmn · README + screenshots/
│   └── lab3-hospital/           hospital-appointment.bpmn · patient-triage.dmn · README + screenshots/
├── worker/                     single Spring Boot app hosting all 3 job workers + all 3 mock APIs
│   ├── pom.xml
│   └── src/main/
│       ├── java/com/pbj/camunda/
│       │   ├── CamundaWorkerApplication.java
│       │   ├── workers/   LoanWorker · OrderWorker · HospitalWorker
│       │   └── mock/      CreditController · PaymentController · SchedulingController
│       └── resources/application.yml
├── docs/                       cross-lab reference material
└── README.md
```

---

## 1 · Prerequisites

| Tool | Use | Notes |
|------|-----|-------|
| [Camunda 8 SaaS](https://camunda.io/explore-saas/free-trial) | Cloud cluster | Free 12-month trial; no infra needed |
| [Camunda Modeler](https://camunda.io/blog/7-introducing-camunda-modeler/) | Edit BPMN/DMN, import to SaaS | `npx camunda-modeler` |
| Java 17+ and Maven | Run the worker + mock API | `mvn -q -DskipTests package` |
| A GitHub account | Submission | One repo is enough |

## 2 · Prepare Camunda 8 SaaS (≈ 5 minutes, once)

1. Sign up at camunda.io and open **Clusters**.
2. Create a **free trial cluster** (select *Camunda 8 · SaaS · Free*). Note the **Cluster URL** (looks like `https://camunda-8-xxx.c8r.io`).
3. In the cluster UI, under **Access management → Authentication**:
   - Create a **Client ID + Client Secret** (Authorization Code or Client Credentials flow — Client Credentials is enough for this assignment).
   - Note the **Audience** (typically the cluster's own URL) and **Base URL**.
4. In **Access management → Members**, make your account a member with *Editor* rights on any workspace (you need it to import models and to see Tasklist/Operate).

> Keep the client secret out of version control. Put it in `worker/src/main/resources/application-local.yml` (git-ignored) or in the `CAMUNDA_CLIENT_ID` / `CAMUNDA_CLIENT_SECRET` environment variables.

## 3 · Import the models (once per lab)

1. Open `models/lab1-loan-approval/loan-approval.bpmn` in Camunda Modeler.
2. Top-right cluster menu → select your SaaS cluster → log in with your credentials.
3. **Import as new / import into** your tenant. Confirm the `loan-eligibility` DMN was deployed together with the process (you can import the `.dmn` first from the *Decision models* panel to be safe).
4. Repeat for labs 2 and 3.

Tip: deploy **DMN first, then BPMN** — a BPMN that references a DMN not yet deployed shows a validation warning.

## 4 · Run the worker + mock API

```bash
cd worker

# one-time: copy the local config template
cp src/main/resources/application-local.yml.example src/main/resources/application-local.yml
# …then edit application-local.yml with YOUR cluster values (never commit it; it is git-ignored)

mvn spring-boot:run -Dspring-boot.run.profiles=local
```

You should see, per lab:

```
Subscribed to external job type: loanValidateApplicant        (Lab 1)
Subscribed to external job type: orderValidateAndPrice        (Lab 2)
Subscribed to external job type: registrationValidate         (Lab 3)
Mock services ready:
  POST http://localhost:8080/mock/credit/assess     (Lab 1)
  POST http://localhost:8080/mock/payment/charge    (Lab 2)
  POST http://localhost:8080/mock/scheduling/slots   (Lab 3)
```

> **The SaaS REST Connector cannot reach `http://localhost:8080` from the cloud.** This is expected and documented in every lab README. Two ways to make the connector path live:
> 1. **Expose the mock API** with a tunnel (e.g. `ngrok http 8080` or `cloudflared`) and set the connector HTTP input mapping to the tunnel URL. This is the cleanest for screenshots.
> 2. **Run Camunda 8 locally** instead: `docker run -p 8081:80 camunda/camunda:8.6` (UIs on `localhost:8081`, mock app keeps `localhost:8080`, so no port clash; point the worker's client at the container per the Camunda 8.6 Spring Boot starter docs). Then `http://localhost:8080` works as-is. Both setups are described in the lab READMEs.
>
> The DMN + external worker + user-task + gateway + incident paths work in either setup — the connector URL is the only difference.

## 5 · The standard run book (apply to every lab)

Each lab's README lists its concrete test inputs. The *method* is identical:

1. **Start instances** — in **Tasklist → Processes**, pick the lab's process definition → *Start instance*, entering the lab's test-case inputs (one instance per test case).
2. **Watch execution** — in **Operate**, open each instance: follow activity states and inspect process variables at each step (variable dictionary in each lab README).
3. **Human task** — whichever instance routed to a user task appears in **Tasklist → Tasks**. Complete it (approve / reject as the test case says) and watch the instance flow to its end event.
4. **Failure & recovery** — trigger the lab's mock-service failure flag (or stop the mock app), start a new instance, watch the job fail → inspect the **incident** in Operate, confirm the root cause shown in the incident message, fix the cause (restart app / clear the flag), then **Retry job** from Operate → the instance completes. Screenshot every step — that is the mandatory recovery evidence.
5. **Screenshots** — copy your captures into `models/<lab>/screenshots/` with the file names given in each lab README. The lab READMEs contain exact "where to click" instructions.

## 6 · What to submit

| Deliverable | Location in this repo |
|-------------|-----------------------|
| BPMN models + design screenshots | `models/<lab>/*.bpmn`, `models/<lab>/screenshots/01-*.png` |
| DMN tables + sample evaluations | `models/<lab>/*.dmn`, section **Decision rules** in each lab README |
| Worker source + run instructions | `worker/`, this README §4, section **Running the worker** in each lab README |
| REST request/response examples | section **Mock REST API** in each lab README |
| Process-variable dictionary | section **Process variables** in each lab README |
| Test-case table (input / expected / actual / status) | section **Test cases** in each lab README — fill the *Actual / Status* columns from your own run |
| Tasklist + Operate + incident evidence | `models/<lab>/screenshots/02…06-*.png` |
| Short report | section **Implementation report** in each lab README |

---

## Design notes & limitations (honesty section)

- One Spring Boot app serves all three labs; in production each would be its own worker.
- The mock APIs simulate deterministic business outcomes from the inputs themselves (credit score, stock level, patient indicators), which is what makes the test cases reproducible; a `forceFailure` flag (or stopping the app) creates the incident paths.
- Camunda 8 SaaS connectors execute REST calls *in the cloud*, so `localhost` targets need a tunnel or a local Docker cluster — both are documented.
- User tasks use the process owner's tenant; assignee/priority are set through process variables so Tasklist shows them immediately.
- All data is synthetic, generated for the educational scenario; nothing in the repo represents a real person, payment, or patient record.
