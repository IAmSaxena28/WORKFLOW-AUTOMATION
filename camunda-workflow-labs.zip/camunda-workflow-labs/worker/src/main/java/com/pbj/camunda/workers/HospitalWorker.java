package com.pbj.camunda.workers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.pbj.camunda.mock.MockState;
import io.camunda.zeebe.client.ZeebeClient;
import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.client.worker.JobContext;
import io.camunda.zeebe.model.messages.ZeebeObjectMapper;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.Optional;

/**
 * LAB 3 — external job worker for the hospital-appointment process.
 *
 * Subscribes to the external task {@code registrationValidate}. It validates
 * the (synthetic) registration fields and requests appointment availability by
 * calling the in-process mock scheduling service. The availability result is
 * returned as process variables for the triage DMN, the gateways and the
 * Tasklist user task.
 */
@Component
public class HospitalWorker {

    private static final Logger log = LoggerFactory.getLogger(HospitalWorker.class);
    private static final String TYPE = "registrationValidate";

    private final ZeebeClient zeebeClient;
    private final ObjectMapper mapper = ZeebeObjectMapper.json();
    private final MockState state;

    public HospitalWorker(ZeebeClient zeebeClient, MockState state) {
        this.zeebeClient = zeebeClient;
        this.state = state;
    }

    @PostConstruct
    void subscribe() {
        zeebeClient.newWorker()
                .jobType(TYPE)
                .timeout(Duration.ofMinutes(1))
                .handler(this::handle)
                .open();
        log.info("Subscribed to external job type: {}", TYPE);
    }

    private void handle(JobContext ctx) {
        ActivatedJob job = ctx.getJob();
        log.info("[{}] job {} variables: {}", TYPE, job.getKey(), job.getVariables());

        if (state.isFailureEnabled()) {
            log.warn("[{}] failure flag on -> failing job to create an incident", TYPE);
            ctx.fail("Simulated scheduling-service failure (failure flag enabled). "
                    + "Disable it (POST /mock/failure/disable), then retry this job in Operate.");
            return;
        }

        // --- read registration variables -------------------------------------------------
        String patientRef        = variable(job, "patientRef", "PAT-UNKNOWN");
        String preferredDate     = variable(job, "preferredDate", null);
        String appointmentPref   = variable(job, "appointmentPreference", "ANY"); // MORNING/AFTERNOON/FULL/ANY
        int    severityScore     = (int) number(job, "severityScore", 0L);   // 0-10 predefined urgency indicator
        boolean vitalConcern    = flag(job, "vitalConcern", false);

        // --- validate --------------------------------------------------------------------
        boolean valid = !patientRef.equals("PAT-UNKNOWN") && preferredDate != null;
        String  validationError = valid ? null
                : "Registration failed validation: missing patient reference or preferred date.";

        // --- request availability via the mock scheduling service ------------------------
        // In a real integration this would be a REST call to the mock API
        // (POST /mock/scheduling/slots). Here the worker resolves slots in-process so
        // the demo runs without a second hop; the REST endpoint exists too for the
        // connector-driven path.
        boolean full = "FULL".equalsIgnoreCase(appointmentPref);
        boolean hasSlots = valid && !full;
        int slotCount = hasSlots ? 3 : 0;

        ctx.complete(mapper.writeValueAsBytes(Map.of(
                "registrationValid", valid,
                "validationError", Optional.ofNullable(validationError),
                "hasAvailableSlots", hasSlots,
                "slotCount", slotCount,
                "needsManualIntervention", !valid || (hasSlots && (severityScore >= 8 || vitalConcern)),
                "validatedAt", Instant.now().toString()
        )));
        log.info("[{}] patient {} -> valid={} slots={} ", TYPE, patientRef, valid, hasSlots);
    }

    private static String variable(ActivatedJob job, String key, String fallback) {
        try {
            String v = job.getVariable(key, String.class);
            return v == null ? fallback : v;
        } catch (Exception e) {
            return fallback;
        }
    }

    private static long number(ActivatedJob job, String key, long fallback) {
        try {
            Object v = job.getVariable(key, Object.class);
            if (v == null) {
                return fallback;
            }
            if (v instanceof Number n) {
                return n.longValue();
            }
            return Long.parseLong(v.toString());
        } catch (Exception e) {
            return fallback;
        }
    }

    private static boolean flag(ActivatedJob job, String key, boolean fallback) {
        try {
            Boolean v = job.getVariable(key, Boolean.class);
            return v == null ? fallback : v;
        } catch (Exception e) {
            return fallback;
        }
    }
}
