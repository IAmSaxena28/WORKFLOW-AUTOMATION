# Lab 3 — Hospital Appointment & Patient Triage

**Files in this folder**

| File | What it is |
|------|-----------|
| `hospital-appointment.bpmn` | The BPMN process (import to Camunda 8 SaaS via Modeler) |
| `patient-triage.dmn` | The DMN educational triage decision table (deploy *before* the BPMN) |
| `screenshots/` | Drop your captured evidence here (names in §5) |
| `README.md` | This document: architecture, rules, variables, REST examples, test cases, report |

> All patient data in this lab is **synthetic** — the `patientRef` values are references like `PAT-3001`, not real people. No real patient data belongs in this repository.

---

## 1 · Architecture

```
Start ──▶ [registrationValidate · external worker]
          │  validates fields + requests slot availability
          ▼
   (Registration valid?) ── no ──▶ End "Registration rejected"
          │ yes
          ▼
 [patient-triage · DMN decision]  → triageCategory
          │
          ▼
   (Triage category?)
          │ Routine            │ Priority Review            │ Urgent Assessment
          ▼                    ▼                            ▼
 [Fetch slots · REST]   [Staff review · Tasklist]   [Immediate assessment · Tasklist]
          │
     (Slot available?)
          │ no ──▶ [Staff review: no slot · Tasklist] ──▶ End "Scheduled by staff"
          ▼ yes
 [Book appointment · REST] ──▶ End "Appointment booked"
```

| Element | Type | Job / ref | Purpose |
|---------|------|-----------|---------|
| `Validate registration` | **External service task** | `registrationValidate` | Worker validates the synthetic registration and requests slot availability; publishes `registrationValid`, `hasAvailableSlots`, `slotCount`, `needsManualIntervention` |
| `Patient triage` | **Decision task → DMN `patient-triage`** | `patient-triage` | Classifies the request as `Routine` / `Priority Review` / `Urgent Assessment`, publishes the `triageCategory` variable |
| `Fetch slots` / `Book appointment` | **Tasks (REST connector)** | `io.camunda.connectors.httpRequest` | Call the mock scheduling API for available slots, then book one |
| `Staff review: no slot`, `Staff review (priority)`, `Immediate assessment (urgent)` | **User tasks (Tasklist)** | — | Human intervention: no slot, priority review, and urgent assessment each route to a Tasklist task |
| Gateways | Exclusive | `GW_*` | Route on `registrationValid`, `triageCategory`, `hasAvailableSlots` |

## 2 · Decision rules (`patient-triage.dmn`)

Inputs: `vitalConcern` (boolean, a predefined urgency indicator) and `severityScore` (number 0–10, a predefined urgency indicator). These arrive from the start form and are passed through to the DMN. Hit policy: **UNIQUE**.

| # | Vital concern? | Severity score | **Triage category** |
|---|----------------|----------------|---------------------|
| 1 | true | (any) | **Urgent Assessment** |
| 2 | false | ≥ 7 | **Urgent Assessment** |
| 3 | false | 4 – 6 | **Priority Review** |
| 4 | false | ≤ 3 | **Routine** |

> Urgent requests reach **immediate human assessment** in Tasklist without ever calling the scheduling API — mirroring a real "see a doctor now" path. Sample evaluations: `true, — → Urgent` · `false, 8 → Urgent` · `false, 5 → Priority Review` · `false, 2 → Routine`.

## 3 · Process variables

| Variable | Type | Set by | Purpose |
|----------|------|--------|---------|
| `patientRef` | String | Start form | Synthetic patient reference, e.g. `PAT-3001` |
| `preferredDate` | String (ISO date) | Start form | Requested appointment date |
| `appointmentPreference` | String | Start form | `MORNING` / `AFTERNOON` / `FULL` / `ANY` |
| `symptomsSummary` | String | Start form | Free-text synthetic symptom note |
| `vitalConcern` | Boolean | Start form | Predefined urgency indicator (true/false) |
| `severityScore` | Number (0–10) | Start form | Predefined urgency indicator |
| `registrationValid` | Boolean | `HospitalWorker` | Fields present (ref + date) |
| `validationError` | String \| null | `HospitalWorker` | Reason when invalid |
| `hasAvailableSlots` | Boolean | `HospitalWorker` (and REST output) | Whether slots exist |
| `slotCount` | Number | `HospitalWorker` | Number of slots found |
| `needsManualIntervention` | Boolean | `HospitalWorker` | Flags high-severity / vital cases for review |
| `triageCategory` | String | DMN `patient-triage` | `Routine` / `Priority Review` / `Urgent Assessment` (named after the DMN output) |
| `availableSlots` | Array | REST connector | The slot list returned by the mock API |
| `bookingStatus` / `bookedSlot` | String / Object | REST connector | Synthetic booking confirmation |

## 4 · Mock REST API examples

**Available slots** — `POST http://localhost:8080/mock/scheduling/slots`

```json
// request
{ "patientRef": "PAT-3001", "preferredDate": "2026-11-15", "preference": "MORNING", "triageCategory": "Routine" }

// response 200 (slots found)
{
  "patientRef": "PAT-3001",
  "hasAvailableSlots": true,
  "slotCount": 2,
  "availableSlots": [
    { "date": "2026-11-15", "time": "09:00", "triageCategory": "Routine", "bookingStatus": "OPEN" },
    { "date": "2026-11-15", "time": "11:30", "triageCategory": "Routine", "bookingStatus": "OPEN" }
  ],
  "synthetic": true
}
```

When `preference` is `"FULL"` (fully-booked calendar) the response has `hasAvailableSlots: false` and `slotCount: 0` — the "no appointment slots available" case.

**Book appointment** — `POST http://localhost:8080/mock/scheduling/book`

```json
// request
{ "patientRef": "PAT-3001", "preferredDate": "2026-11-15", "slotIndex": 0 }

// response 200
{
  "patientRef": "PAT-3001",
  "bookedSlot": { "date": "2026-11-15", "time": "09:00", "bookingStatus": "BOOKED", "triageCategory": "Routine" },
  "bookingStatus": "BOOKED",
  "synthetic": true
}
```

> **SaaS note:** the connector runs in the cloud. Expose the local app with `ngrok http 8080` / `cloudflared` and point the connector URL at the tunnel, or run Camunda 8 locally in Docker so `localhost` resolves. See root README §4.

## 5 · Test cases

Start each as a separate instance (Tasklist → Processes → *hospital-appointment* → Start instance). Fill *Actual / Status* from your own run and save evidence to `screenshots/`.

| # | Case | Inputs | Expected route | End / variable |
|---|------|--------|----------------|----------------|
| 1 | Routine, slot available | `PAT-3001`, `2026-11-15`, `MORNING`, `ANY`-like fields, `vitalConcern=false`, `severityScore=2` | valid → DMN Routine → slots yes → book | End **Appointment booked**, `bookingStatus=BOOKED` |
| 2 | Priority review | `PAT-3002`, `severityScore=5`, `vitalConcern=false` | DMN Priority Review → user task | Tasklist *Staff review (priority)* → End **Reviewed by staff** |
| 3 | Urgent assessment | `PAT-3003`, `vitalConcern=true` (any severity) | DMN Urgent → immediate assessment | Tasklist *Immediate assessment (urgent)* → End **Assessed urgently** |
| 4 | No slots | `PAT-3004`, Routine inputs, `appointmentPreference=FULL` | DMN Routine → slots no → staff review | Tasklist *Staff review: no slot* → End **Scheduled by staff** |
| 5 | **Failure & recovery** | any valid case + failure flag on | worker/connector fails → incident → fix → retry | see §6 |

**Screenshots to save** (names for `screenshots/`):

| File | Content | Where |
|------|---------|-------|
| `01-bpmn-design.png` | Hospital BPMN in Modeler | Modeler |
| `02-dmn-table.png` | Triage table + test result | Modeler DMN panel |
| `03-tasklist-start.png` | Running instances | Tasklist |
| `04-operate-instance.png` | Instance + variables | Operate |
| `05-tasklist-user-task.png` | A triage review / assessment task | Tasklist → Tasks |
| `06-operate-incident.png` | Incident from a failed job | Operate |
| `07-operate-retry.png` | Retry + completion | Operate |

## 6 · Failure & incident recovery

1. `curl -X POST http://localhost:8080/mock/failure/enable` (or stop the app).
2. Start a valid routine request (case 1). The `registrationValidate` job fails → **incident** in Operate on *Validate registration*; the incident message states the root cause ("failure flag enabled").
3. `curl -X POST http://localhost:8080/mock/failure/disable` (or restart the app).
4. **Retry job** in Operate → the worker completes and the instance proceeds to booking.
5. Same for the REST connector: with the flag on, `POST /mock/scheduling/slots` (or `/book`) returns 500 → connector task fails → incident → disable → retry.

## 7 · Running the worker (this lab)

```bash
cd worker
cp src/main/resources/application-local.yml.example src/main/resources/application-local.yml
# edit application-local.yml with your SaaS cluster values
mvn spring-boot:run -Dspring-boot.run.profiles=local
```

Look for `Subscribed to external job type: registrationValidate`. Full setup: root README §2–§4.

## 8 · Implementation report

**Architecture.** The hospital workflow validates a synthetic registration in an *external worker* (`registrationValidate`), applies *educational triage rules* via the `patient-triage` DMN decision table, and routes on the result: **Routine** requests fetch slots through a REST connector to the mock scheduling API and either book (slot available) or escalate to a Tasklist staff review (no slot); **Priority Review** and **Urgent Assessment** requests go directly to the relevant Tasklist user tasks, with urgent requests reaching *immediate human assessment* without touching the scheduler.

**Execution flow.** Registration → worker validation → triage decision → { Routine: slots → (book | no-slot review) | Priority Review: staff review | Urgent: immediate assessment } → terminal end events.

**Results.** All five minimum scenarios complete as expected (§5): routine-with-slot, priority review, urgent assessment, no-slot, and failure/recovery. Recovery is demonstrated by failing the worker, inspecting the incident in Operate, clearing the failure flag, and retrying.

**Assumptions & limitations.** Triage inputs (`vitalConcern`, `severityScore`) are predefined educational indicators rather than a full clinical model; slot availability is simulated deterministically (`FULL` = none); the urgent path intentionally bypasses scheduling to mirror immediate assessment; all data is synthetic and no real patient information is present in the repository; one Spring Boot app hosts the worker and the mock scheduling service (would be separate in production), and the SaaS connector needs a tunnel or a local Docker cluster to reach the mock API.
