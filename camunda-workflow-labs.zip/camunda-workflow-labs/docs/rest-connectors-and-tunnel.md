# REST Connector & Mock-API Reachability (cross-lab reference)

All three labs use the **out-of-the-box HTTP connector** (`io.camunda.connectors.httpRequest`). The connector's request/response bodies are built from small JavaScript input/output mappings that read **process variables** and write results back. This page explains the one wrinkle specific to Camunda 8 **SaaS** and gives you two options to make the REST path live.

## Why `localhost` doesn't just work on SaaS

- The **external job worker** is a process *you* run (`worker/` app). It connects **out** to your SaaS cluster over HTTPS and can freely call anything on `localhost`. So the worker → mock flow works with no extra setup.
- The **REST connector** executes **inside the cloud** (Camunda SaaS). It cannot reach `http://localhost:8080` on your laptop. So the connector needs a URL the cloud can reach.

## Option A — expose the mock API with a tunnel (recommended for screenshots)

1. Run the worker app: `cd worker && mvn spring-boot:run -Dspring-boot.run.profiles=local` (mock APIs start on `:8080`).
2. Open a tunnel to that port:
   - **ngrok:** `ngrok http 8080` → gives you `https://xxxx.ngrok-free.app`
   - **Cloudflare:** `cloudflared tunnel --url http://localhost:8080` → `https://...trycloudflare.com`
3. In Modeler, open each lab's `.bpmn`, select each REST-connector task, and change the input-mapping `url` from `http://localhost:8080/...` to the tunnel host, e.g. `https://xxxx.ngrok-free.app/mock/credit/assess`.
4. Re-import the updated `.bpmn` into your SaaS cluster.
5. Run a test instance — the connector now reaches your mock API through the tunnel.

> Keep the tunnel open for the whole run. Re-import only after the URL change; the process definition version updates on re-import.

## Option B — run Camunda 8 locally (Docker)

```bash
# one-time, ~2 min
docker run -p 8080:8080 -p 80/80 camunda/camunda:8.6
# Tasklist/Operate/Modeler/Console UIs: http://localhost:80
# Zeebe API (used by the worker): http://localhost:8080
```

Then point the worker's `camunda.client` block at `http://localhost:8080` and keep the connector URLs at `http://localhost:8080/...` (the cloud is no longer involved, so `localhost` is reachable). This is the simplest path if you'd rather not use the SaaS trial.

## Connector mapping quick reference

| Concern | Where it lives | Notes |
|---------|----------------|-------|
| Method / URL | `zeebe:input` script, `result.method` / `result.url` | Swap in the tunnel host for SaaS |
| Request body | `result.body` (JSON.stringify of process variables) | Synthetic payloads only |
| Response → variables | `zeebe:output` script, `result?.field` | `result` is the parsed HTTP response body |
| Gateway on the outcome | Exclusive gateway, FEEL condition on the output variable | e.g. `paymentDeclined`, `creditDeclined`, `hasAvailableSlots` |

## Reusing the failure flag across all labs

`POST /mock/failure/enable` (and `/disable`, `/status`) toggles one in-app flag that:
- makes the mock endpoints return **HTTP 500** (drives a **connector** incident), and
- makes the external workers call `ctx.fail(...)` (drives a **worker** incident).

That single switch powers every "failure → incident → fix → retry" test case in Labs 1, 2 and 3.
