# Lab 2 — E-commerce Order Processing & Fulfilment

**Files in this folder**

| File | What it is |
|------|-----------|
| `order-processing.bpmn` | The BPMN process (import to Camunda 8 SaaS via Modeler) |
| `order-priority.dmn` | The DMN priority decision table (deploy *before* the BPMN) |
| `screenshots/` | Drop your captured evidence here (names in §5) |
| `README.md` | This document: architecture, rules, variables, REST examples, test cases, report |

---

## 1 · Architecture

```
Start ──▶ [orderValidateAndPrice · external worker]
          │  validates, checks simulated stock, calculates orderTotal
          ▼
     (Order valid & in stock?) ── no ──▶ End "Order cancelled: invalid/out of stock"
          │ yes
          ▼
 [order-priority · DMN decision]  → priority = HIGH / NORMAL / LOW
          │
          ▼
   (Priority HIGH?)
          │ yes                          │ no
          ▼                              ▼
 [Manual verification · Tasklist]    [Process payment · REST connector]
          │
     (Verified? = confirmed)  ── no ──▶ End "Cancelled by reviewer"
          │ yes
          ▼
 [Process payment · REST connector]  → paymentStatus CAPTURED | DECLINED
          │
     (Payment captured?)
          │ no ──▶ End "Order not fulfilled: payment declined"
          ▼ yes
 [Fulfil order · REST connector] ──▶ End "Order fulfilled"
```

| Element | Type | Job / ref | Purpose |
|---------|------|-----------|---------|
| `Validate & price order` | **External service task** | `orderValidateAndPrice` | Worker validates the order, checks the simulated catalogue stock, computes `orderTotal`; publishes `orderValid`, `stockAvailable`, `orderTotal`, `stockOnHand` |
| `Order priority` | **Decision task → DMN `order-priority`** | `order-priority` | Evaluates the priority table, publishes the `priority` variable |
| `Manual verification` | **User task (Tasklist)** | — | Human confirms high-value/exception orders; sets `confirmed` |
| `Process payment` | **Task (REST connector)** | `io.camunda.connectors.httpRequest` | Calls the mock payment gateway; publishes `paymentStatus`, `paymentDeclined`, `paymentRef` |
| `Fulfil order` | **Task (REST connector)** | `io.camunda.connectors.httpRequest` | Simulated fulfilment call on the captured path |
| Gateways | Exclusive | `GW_*` | Route on `orderValid`+`stockAvailable`, `priority`, `confirmed`, `paymentDeclined` |

## 2 · Decision rules (`order-priority.dmn`)

Inputs: `orderTotal` (from the worker), `customerCategory` (`SILVER | GOLD | PLATINUM`), `deliveryPreference` (`STANDARD | EXPRESS`). Hit policy: **UNIQUE**, with a default (all-"any") rule that yields `NORMAL`.

| # | Order total | Customer category | Delivery preference | **Priority** |
|---|-------------|-------------------|---------------------|--------------|
| 1 | ≥ 1000 | (any) | EXPRESS | **HIGH** |
| 2 | ≥ 500 | GOLD | (any) | **HIGH** |
| 3 | < 100 | SILVER | STANDARD | **LOW** |
| 4 | (any) | (any) | (any) — default | **NORMAL** |

> High-value **or** exception orders therefore resolve to `HIGH` and are routed to the Tasklist user task for manual verification before payment. Sample evaluations: `1200 / GOLD / EXPRESS → HIGH` · `600 / SILVER / STANDARD → NORMAL` · `80 / SILVER / STANDARD → LOW` · `520 / GOLD / STANDARD → HIGH`.

## 3 · Process variables

| Variable | Type | Set by | Purpose |
|----------|------|--------|---------|
| `customerRef` | String | Start form | Synthetic order/customer reference, e.g. `ORD-2001` |
| `productId` | String | Start form | One of `P-1001`…`P-1004` (see worker catalogue) |
| `quantity` | Number | Start form | Units requested |
| `deliveryPreference` | String | Start form | `STANDARD` / `EXPRESS` |
| `customerCategory` | String | Start form | `SILVER` / `GOLD` / `PLATINUM` |
| `paymentToken` | String | Start form | Synthetic token; ending in `0000` simulates a decline |
| `orderValid` | Boolean | `OrderWorker` | Product known, quantity > 0, ref present |
| `stockAvailable` | Boolean | `OrderWorker` | Catalogue stock ≥ quantity |
| `stockOnHand` | Number | `OrderWorker` | Available units (evidence) |
| `orderTotal` | Number | `OrderWorker` | unit price × quantity, rounded to 2 dp |
| `priority` | String | DMN `order-priority` | `HIGH` / `NORMAL` / `LOW` |
| `confirmed` | Boolean | Reviewer in Tasklist | High-value verification outcome |
| `paymentStatus` | String | REST connector | `CAPTURED` / `DECLINED` |
| `paymentDeclined` | Boolean | REST connector output | Drives the payment gateway branch |
| `orderStatus` / `fulfilmentRef` | String | REST connector | Synthetic fulfilment result |

**Simulated catalogue** (in `OrderWorker`, all synthetic):

| Product | Unit price | Stock |
|---------|-----------|-------|
| `P-1001` | 25.00 | 120 |
| `P-1002` | 149.90 | 40 |
| `P-1003` | 899.00 | 12 |
| `P-1004` | 59.50 | 0 *(out of stock on purpose)* |

## 4 · Mock REST API examples

**Payment** — `POST http://localhost:8080/mock/payment/charge`

```json
// request
{ "orderRef": "ORD-2001", "amount": 399.80, "paymentToken": "synth-tok-8842", "customerCategory": "GOLD" }

// response 200
{
  "orderRef": "ORD-2001",
  "amount": 399.80,
  "paymentStatus": "CAPTURED",
  "paymentRef": "PAY-48213",
  "declinedReason": null,
  "synthetic": true
}
```

A `paymentToken` ending in `0000` returns `paymentStatus: "DECLINED"` with `declinedReason: "insufficient_funds"` (the payment-decline test case).

**Fulfilment** — `POST http://localhost:8080/mock/order/fulfil`

```json
// request
{ "orderRef": "ORD-2001", "action": "FULFIL", "priority": "HIGH", "deliveryPreference": "EXPRESS" }

// response 200
{ "orderRef": "ORD-2001", "orderStatus": "FULFILLED", "fulfilmentRef": "FUL-1204", "priority": "HIGH", "deliveryPreference": "EXPRESS", "synthetic": true }
```

> **SaaS note:** the connector runs in the cloud. Expose the local app with `ngrok http 8080` / `cloudflared` and point the connector URL at the tunnel, or run Camunda 8 locally in Docker so `localhost` resolves. See root README §4.

## 5 · Test cases

Start each as a separate instance (Tasklist → Processes → *order-processing* → Start instance). Fill *Actual / Status* from your own run and save evidence to `screenshots/`.

| # | Case | Inputs | Expected route | End / variable |
|---|------|--------|----------------|----------------|
| 1 | Happy path, normal priority | `ORD-2001`, `P-1001` ×10, `STANDARD`, `SILVER`, token `synth-8842` | valid+stock → total 250 → DMN NORMAL → payment CAPTURED → fulfil | End **Order fulfilled**, `orderStatus=FULFILLED` |
| 2 | Out of stock | `ORD-2002`, `P-1004` ×2 | worker: stockAvailable=false | End **Order cancelled: invalid/out of stock** |
| 3 | Payment declined | `ORD-2003`, `P-1002` ×2, token ending `0000` | paid path → gateway DECLINED | End **Order not fulfilled: payment declined** |
| 4 | High-value manual review | `ORD-2004`, `P-1003` ×2 (total 1798), `EXPRESS`, `GOLD` | DMN HIGH → user task | Tasklist task; complete with `confirmed=true` → **Order fulfilled** |
| 5 | **Failure & recovery** | any valid case + failure flag on | worker/connector fails → incident → fix → retry | see §6 |

**Screenshots to save** (names for `screenshots/`):

| File | Content | Where |
|------|---------|-------|
| `01-bpmn-design.png` | Order BPMN in Modeler | Modeler |
| `02-dmn-table.png` | Priority table + test result | Modeler DMN panel |
| `03-tasklist-start.png` | Running instances | Tasklist |
| `04-operate-instance.png` | Instance + variables | Operate |
| `05-tasklist-user-task.png` | The manual-verification task | Tasklist → Tasks |
| `06-operate-incident.png` | Incident from a failed job | Operate |
| `07-operate-retry.png` | Retry + completion | Operate |

## 6 · Failure & incident recovery

1. `curl -X POST http://localhost:8080/mock/failure/enable` (or stop the app).
2. Start a valid order (e.g. case 1). The `orderValidateAndPrice` job fails → **incident** in Operate on the *Validate & price order* step; the incident message is the root cause ("failure flag enabled").
3. `curl -X POST http://localhost:8080/mock/failure/disable` (or restart the app).
4. **Retry job** in Operate → the worker completes, the instance continues to fulfilment.
5. Same for the REST connector: with the flag on, `POST /mock/payment/charge` returns 500 → connector task fails → incident → disable → retry.

## 7 · Running the worker (this lab)

```bash
cd worker
cp src/main/resources/application-local.yml.example src/main/resources/application-local.yml
# edit application-local.yml with your SaaS cluster values
mvn spring-boot:run -Dspring-boot.run.profiles=local
```

Look for `Subscribed to external job type: orderValidateAndPrice`. Full setup: root README §2–§4.

## 8 · Implementation report

**Architecture.** The order workflow chains an *external worker* (`orderValidateAndPrice`) that performs validation + simulated inventory check + total calculation, a *DMN decision task* that resolves delivery priority from order value, customer category and delivery preference, a *Tasklist user task* for high-value/exception orders, and two *REST connectors* (payment gateway and fulfilment) that exchange synthetic data with the mock API.

**Execution flow.** Order → validate/price → priority decision → (HIGH: manual verification →) payment → (declined: terminate | captured: fulfil) → order fulfilled.

**Results.** All five minimum scenarios complete as expected (§5); recovery is demonstrated by failing the worker, inspecting the incident in Operate, clearing the failure flag, and retrying the job.

**Assumptions & limitations.** One Spring Boot app hosts the worker and both mock services (would be separate services in production); the catalogue and payment outcomes are deterministic for reproducible testing; the SaaS connector cannot reach `localhost`, so a tunnel or a local Docker cluster is used; `P-1004` is intentionally out of stock to drive the inventory test case; all data is synthetic.
