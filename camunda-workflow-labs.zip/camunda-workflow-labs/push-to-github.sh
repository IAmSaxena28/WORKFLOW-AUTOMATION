#!/usr/bin/env bash
# ============================================================================
# push-to-github.sh — publish these lab files INTO your EXISTING repo, as a
# subfolder. Your existing files are left untouched; this only ADDS a
# camunda-workflow-labs/ subfolder with one commit on top.
#
# Target:  https://github.com/IAmSaxena28/WORKFLOW-AUTOMATION
#
# What it does:
#   1. clones your repo into a temp dir (fetches everything you already have)
#   2. copies these lab files into <repo>/camunda-workflow-labs/
#   3. git add + commit that subfolder
#   4. pushes to origin (asks for your token once, typed hidden)
#
# Prereqs on your machine: git + bash. That's it.
#
# Usage:   ./push-to-github.sh            (uses the defaults below)
#          ./push-to-github.sh            # from anywhere; it finds itself
#
# Token scopes: for a PUBLIC repo, a classic token with `public_repo` (or a
# fine-grained token with Contents: Read&Write on this one repo, 1-hour
# expiry). Never your account password, never a long-lived admin token.
# ============================================================================
set -euo pipefail

GITHUB_USER="${1:-IAmSaxena28}"
REPO_NAME="${2:-WORKFLOW-AUTOMATION}"
SUBFOLDER="${3:-camunda-workflow-labs}"

# This script lives inside the lab folder, so locate it (works from anywhere).
LAB_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [[ ! -f "$LAB_DIR/README.md" ]]; then
  echo "!! Can't find the lab README next to this script. Run it from the camunda-workflow-labs folder."
  exit 1
fi

WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
REPO="$WORK/$REPO_NAME"

echo ">> Cloning https://github.com/${GITHUB_USER}/${REPO_NAME} …"
# Clone (shallow is fine; we only add one commit).
if ! git clone --depth 1 "https://github.com/${GITHUB_USER}/${REPO_NAME}.git" "$REPO"; then
  echo "!! Clone failed. Is the repo public? If it's private, the token you're about to"
  echo "   enter must have access, or use the private-repo token before cloning:"
  echo "     git clone https://<token>@github.com/${GITHUB_USER}/${REPO_NAME}.git $REPO"
  exit 1
fi

echo ">> Copying lab files into ${SUBFOLDER}/"
mkdir -p "$REPO/${SUBFOLDER}"
# Copy contents of the lab folder (dotfiles like .gitignore included) into the subfolder.
cp -R "$LAB_DIR/." "$REPO/${SUBFOLDER}/"

# Keep the secret-bearing local config out of the commit (defence in depth;
# .gitignore already excludes it, but don't rely on one thing).
rm -f "$REPO/${SUBFOLDER}/worker/src/main/resources/application-local.yml"

cd "$REPO"
git add "${SUBFOLDER}"

# Refuse to commit anything that looks like a secret under our subfolder.
if git diff --cached --name-only | grep -qE 'application-local\.yml$|\.env$|client-secret'; then
  echo "!! A secret-looking file is staged under ${SUBFOLDER}/. Aborting — nothing pushed."
  git diff --cached --name-only | grep -E 'application-local\.yml$|\.env$|client-secret'
  exit 1
fi

git commit -m "Add Camunda 8 PBJ-2 Labs 1-3 (BPMN + DMN + Spring Boot workers & mock APIs)" \
  -m "Drop-in subfolder ${SUBFOLDER}/: three end-to-end workflow implementations with models, Java workers, mock REST services, and full documentation. Existing repo content is unchanged."

# Detect the repo's default branch (main or master) from the clone.
BRANCH="$(git symbolic-ref --short HEAD)"

# --- push with your token (asked once, in-memory only, never written) ------
read -r -s -p "Enter GitHub Personal Access Token (typed hidden; public_repo scope): " GIT_TOKEN
echo
URL="https://${GITHUB_USER}:${GIT_TOKEN}@github.com/${GITHUB_USER}/${REPO_NAME}.git"
echo "Pushing to ${GITHUB_USER}/${REPO_NAME} (branch: ${BRANCH})…"
if GIT_ASKPASS= git -c credential.helper= push "$URL" "HEAD:${BRANCH}"; then
  echo
  echo "Done! Open https://github.com/${GITHUB_USER}/${REPO_NAME} — your files are now in /${SUBFOLDER}/."
  echo "Everything you already had is intact. Next: run the labs, add screenshots into ${SUBFOLDER}/models/<lab>/screenshots/, then commit those too."
else
  echo
  echo "Push failed. Common causes:"
  echo "  - token lacks write access to this repo (use a fine-grained token with Contents: Read&Write)"
  echo "  - push was rejected (someone pushed to ${BRANCH} meanwhile): retry once more"
  exit 1
fi
# Clean up so the token isn't left in shell history/env.
unset GIT_TOKEN
