package com.pbj.camunda.workers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.pbj.camunda.mock.MockState;
import io.camunda.zeebe.client.ZeebeClient;
import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.client.worker.JobContext;
import io.camunda.zeebe.model.messages.ZeebeObjectMapper;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.Optional;

/**
 * LAB 1 — external job worker for the loan-approval process.
 *
 * Subscribes to the external task {@code loanValidateApplicant} in
 * loan-approval.bpmn. It validates the applicant (identity, income, amount
 * sanity) and writes the validation result back as process variables, which
 * the DMN decision and the downstream gateways then consume.
 */
@Component
public class LoanWorker {

    private static final Logger log = LoggerFactory.getLogger(LoanWorker.class);
    private static final String TYPE = "loanValidateApplicant";

    private final ZeebeClient zeebeClient;
    private final ObjectMapper mapper = ZeebeObjectMapper.json();
    private final MockState state;

    public LoanWorker(ZeebeClient zeebeClient, MockState state) {
        this.zeebeClient = zeebeClient;
        this.state = state;
    }

    @PostConstruct
    void subscribe() {
        zeebeClient.newWorker()
                .jobType(TYPE)
                .timeout(Duration.ofMinutes(1))
                .handler(this::handle)
                .open();
        log.info("Subscribed to external job type: {}", TYPE);
    }

    private void handle(JobContext ctx) {
        ActivatedJob job = ctx.getJob();
        log.info("[{}] job {} variables: {}", TYPE, job.getKey(), job.getVariables());

        // Failure drill: when the flag is on, fail the job so Operate raises an
        // incident. Clear the flag and retry the job to recover.
        if (state.isFailureEnabled()) {
            log.warn("[{}] failure flag on -> failing job to create an incident", TYPE);
            ctx.fail("Simulated worker failure: validation dependency unavailable (failure flag enabled). "
                    + "Disable it (POST /mock/failure/disable), then retry this job in Operate.");
            return;
        }

        // --- read applicant variables --------------------------------------------------
        String applicantId  = variable(job, "applicantId", "APP-UNKNOWN");
        long   requestedLoan = number(job, "requestedLoanAmount", 0L);
        long   monthlyIncome = number(job, "monthlyIncome", 0L);

        // --- validate ------------------------------------------------------------------
        boolean applicantValid = !applicantId.equals("APP-UNKNOWN")
                && requestedLoan > 0
                && monthlyIncome > 0;
        String validationError = applicantValid ? null
                : "Applicant failed basic validation (missing id, non-positive loan amount, or non-positive income).";

        long debtToIncomePct = monthlyIncome > 0
                ? Math.round((double) requestedLoan / (monthlyIncome * 60.0) * 100.0)
                : -1;

        // --- write results back as process variables ----------------------------------
        ctx.complete(mapper.writeValueAsBytes(Map.of(
                "applicantValid", applicantValid,
                "validationError", Optional.ofNullable(validationError),
                "debtToIncomePct", debtToIncomePct,
                "validatedAt", Instant.now().toString()
        )));
        log.info("[{}] completed for {} (valid={})", TYPE, applicantId, applicantValid);
    }

    private static String variable(ActivatedJob job, String key, String fallback) {
        try {
            String v = job.getVariable(key, String.class);
            return v == null ? fallback : v;
        } catch (Exception e) {
            return fallback;
        }
    }

    private static long number(ActivatedJob job, String key, long fallback) {
        try {
            Object v = job.getVariable(key, Object.class);
            if (v == null) {
                return fallback;
            }
            if (v instanceof Number n) {
                return n.longValue();
            }
            return Long.parseLong(v.toString());
        } catch (Exception e) {
            return fallback;
        }
    }
}
