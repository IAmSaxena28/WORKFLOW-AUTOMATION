package com.pbj.camunda.mock;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * LAB 1 — simulated credit-assessment API.
 *
 * The BPMN REST Connector calls this after the external worker has validated
 * the applicant. It deterministically derives a credit score + assessment from
 * the (synthetic) applicant data, so test cases are reproducible.
 */
@RestController
@RequestMapping("/mock/credit")
public class CreditController {

    private final MockState state;

    public CreditController(MockState state) {
        this.state = state;
    }

    public record AssessRequest(
            String applicantId,
            Long requestedAmount,
            Long monthlyIncome,
            Integer creditScore      // synthetic 300-850
    ) {}

    @PostMapping("/assess")
    public ResponseEntity<Map<String, Object>> assess(@RequestBody AssessRequest req) {
        if (state.isFailureEnabled()) {
            // Simulates the "credit-assessment API error / timeout" test case.
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "CREDIT_SERVICE_UNAVAILABLE",
                            "message", "Simulated credit service outage (failure flag enabled)."));
        }

        int score = req.creditScore() == null ? 0 : req.creditScore();
        long debtRatio = 0;
        if (req.monthlyIncome() != null && req.requestedAmount() != null) {
            debtRatio = Math.round((double) req.requestedAmount() / Math.max(1, req.monthlyIncome() * 60) * 100);
        }

        boolean creditOk = score >= 700;
        boolean creditPoor = score < 600;

        Map<String, Object> body = new LinkedHashMap<>();
        body.put("creditScore", score);
        body.put("debtToIncomePct", debtRatio);
        body.put("creditAssessment", creditOk ? "GOOD" : (creditPoor ? "POOR" : "FAIR"));
        body.put("creditApproved", creditOk);
        body.put("creditDeclined", creditPoor);
        body.put("creditNeedsReview", !creditOk && !creditPoor); // mid-band -> review
        body.put("synthetic", true);
        return ResponseEntity.ok(body);
    }
}
