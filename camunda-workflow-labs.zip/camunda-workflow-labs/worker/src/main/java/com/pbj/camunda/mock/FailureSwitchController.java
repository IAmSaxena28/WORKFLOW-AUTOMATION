package com.pbj.camunda.mock;

import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * The single lever used to demonstrate failure + incident recovery in all labs.
 *
 *   POST /mock/failure/enable  -> mock endpoints return 500, workers fail their job
 *   GET  /mock/failure/status  -> {"failureEnabled": true|false}
 *   POST /mock/failure/disable -> services recover -> retry the incident in Operate
 */
@RestController
@RequestMapping("/mock/failure")
public class FailureSwitchController {

    private final MockState state;

    public FailureSwitchController(MockState state) {
        this.state = state;
    }

    @PostMapping("/enable")
    public Map<String, Object> enable() {
        boolean now = state.setFailureEnabled(true);
        return Map.of("failureEnabled", now);
    }

    @PostMapping("/disable")
    public Map<String, Object> disable() {
        state.clearFailure();
        return Map.of("failureEnabled", false);
    }

    @GetMapping("/status")
    public Map<String, Object> status() {
        return Map.of("failureEnabled", state.isFailureEnabled());
    }
}
