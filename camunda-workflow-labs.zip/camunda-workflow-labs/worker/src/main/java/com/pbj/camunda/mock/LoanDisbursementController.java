package com.pbj.camunda.mock;

import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * LAB 1 — simulated disbursement/notify endpoint. The "Disburse loan (REST)"
 * connector calls this once the DMN decision is Approved. Purely synthetic.
 */
@RestController
@RequestMapping("/mock/loan")
public class LoanDisbursementController {

    public record DisburseRequest(String applicantId, Long requestedAmount) {}

    @PostMapping("/disburse")
    public Map<String, Object> disburse(@RequestBody DisburseRequest req) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("applicantId", req.applicantId());
        body.put("requestedAmount", req.requestedAmount());
        body.put("disbursementRef", "DISB-" + System.currentTimeMillis());
        body.put("synthetic", true);
        return body;
    }
}
