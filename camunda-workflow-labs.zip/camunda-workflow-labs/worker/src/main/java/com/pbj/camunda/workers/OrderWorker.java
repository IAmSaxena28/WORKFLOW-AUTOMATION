package com.pbj.camunda.workers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.pbj.camunda.mock.MockState;
import io.camunda.zeebe.client.ZeebeClient;
import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.client.worker.JobContext;
import io.camunda.zeebe.model.messages.ZeebeObjectMapper;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.Optional;

/**
 * LAB 2 — external job worker for the order-processing process.
 *
 * Subscribes to the external task {@code orderValidateAndPrice}. It validates
 * the order, checks simulated inventory (from a small in-memory catalogue),
 * calculates the order total, and returns them as process variables for the
 * DMN priority decision, the payment connector and the gateways.
 */
@Component
public class OrderWorker {

    private static final Logger log = LoggerFactory.getLogger(OrderWorker.class);
    private static final String TYPE = "orderValidateAndPrice";

    // Synthetic catalogue: product -> (unit price, stock on hand).
    private static final Map<String, double[]> CATALOGUE = Map.of(
            "P-1001", new double[]{ 25.00,  120 },   // e.g. "Wireless Mouse"
            "P-1002", new double[]{ 149.90, 40 },    // e.g. "Bluetooth Headset"
            "P-1003", new double[]{ 899.00, 12 },    // e.g. "4K Webcam Pro"
            "P-1004", new double[]{ 59.50, 0 }       // out of stock on purpose
    );

    private final ZeebeClient zeebeClient;
    private final ObjectMapper mapper = ZeebeObjectMapper.json();
    private final MockState state;

    public OrderWorker(ZeebeClient zeebeClient, MockState state) {
        this.zeebeClient = zeebeClient;
        this.state = state;
    }

    @PostConstruct
    void subscribe() {
        zeebeClient.newWorker()
                .jobType(TYPE)
                .timeout(Duration.ofMinutes(1))
                .handler(this::handle)
                .open();
        log.info("Subscribed to external job type: {}", TYPE);
    }

    private void handle(JobContext ctx) {
        ActivatedJob job = ctx.getJob();
        log.info("[{}] job {} variables: {}", TYPE, job.getKey(), job.getVariables());

        if (state.isFailureEnabled()) {
            log.warn("[{}] failure flag on -> failing job to create an incident", TYPE);
            ctx.fail("Simulated inventory service failure (failure flag enabled). "
                    + "Disable it (POST /mock/failure/disable), then retry this job in Operate.");
            return;
        }

        // --- read order variables -------------------------------------------------------
        String orderRef   = variable(job, "customerRef", "ORD-UNKNOWN");
        String product    = variable(job, "productId", "P-1001");
        int    quantity    = (int) number(job, "quantity", 1L);

        double[] item = CATALOGUE.get(product);
        boolean  valid = item != null && quantity > 0 && !orderRef.equals("ORD-UNKNOWN");
        if (!valid) {
            ctx.complete(mapper.writeValueAsBytes(Map.of(
                    "orderValid", false,
                    "orderTotal", 0.0,
                    "stockAvailable", false,
                    "stockOnHand", 0L,
                    "orderError", "Unknown product, non-positive quantity, or missing customer reference."
            )));
            log.info("[{}] order {} marked invalid", TYPE, orderRef);
            return;
        }

        // --- simulated inventory check + total ------------------------------------------
        double unitPrice = item[0];
        long   onHand    = (long) item[1];
        boolean stockAvailable = onHand >= quantity;
        double   orderTotal   = Math.round(unitPrice * quantity * 100.0) / 100.0;

        ctx.complete(mapper.writeValueAsBytes(Map.of(
                "orderValid", true,
                "stockAvailable", stockAvailable,
                "stockOnHand", onHand,
                "unitPrice", unitPrice,
                "orderTotal", orderTotal,
                "pricedAt", Instant.now().toString()
        )));
        log.info("[{}] order {} -> total {} (stock: {})", TYPE, orderRef, orderTotal, stockAvailable);
    }

    private static String variable(ActivatedJob job, String key, String fallback) {
        try {
            String v = job.getVariable(key, String.class);
            return v == null ? fallback : v;
        } catch (Exception e) {
            return fallback;
        }
    }

    private static long number(ActivatedJob job, String key, long fallback) {
        try {
            Object v = job.getVariable(key, Object.class);
            if (v == null) {
                return fallback;
            }
            if (v instanceof Number n) {
                return n.longValue();
            }
            return Long.parseLong(v.toString());
        } catch (Exception e) {
            return fallback;
        }
    }
}
