package com.pbj.camunda.mock;

import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * LAB 2 — simulated fulfilment endpoint called by the "Fulfil order (REST)"
 * connector once payment is captured.
 */
@RestController
@RequestMapping("/mock/order")
public class OrderFulfilmentController {

    public record FulfilRequest(
            String orderRef,
            String action,
            String priority,
            String deliveryPreference
    ) {}

    @PostMapping("/fulfil")
    public Map<String, Object> fulfil(@RequestBody FulfilRequest req) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("orderRef", req.orderRef());
        body.put("orderStatus", "FULFILLED");
        body.put("fulfilmentRef", "FUL-" + Math.abs(req.orderRef().hashCode() % 100000));
        body.put("priority", req.priority());
        body.put("deliveryPreference", req.deliveryPreference());
        body.put("synthetic", true);
        return body;
    }
}
