package com.pbj.camunda.mock;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * LAB 3 — simulated hospital scheduling API.
 *
 * Returns a small deterministic list of available slots. When the caller asks
 * for a "FULL" preference (representing a fully-booked calendar) it returns no
 * slots, which drives the "no appointment slots available" test case.
 */
@RestController
@RequestMapping("/mock/scheduling")
public class SchedulingController {

    private final MockState state;

    public SchedulingController(MockState state) {
        this.state = state;
    }

    public record SlotsRequest(
            String patientRef,
            String preferredDate,     // synthetic
            String preference,        // "MORNING" | "AFTERNOON" | "FULL"
            String triageCategory
    ) {}

    public record BookRequest(
            String patientRef,
            String preferredDate,
            Integer slotIndex
    ) {}

    @PostMapping("/slots")
    public ResponseEntity<Map<String, Object>> slots(@RequestBody SlotsRequest req) {
        if (state.isFailureEnabled()) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "SCHEDULING_SERVICE_UNAVAILABLE",
                            "message", "Simulated scheduling outage (failure flag enabled)."));
        }

        List<Map<String, Object>> slots = new ArrayList<>();
        boolean noSlots = "FULL".equalsIgnoreCase(req.preference());
        if (!noSlots) {
            LocalDate date = parseSafe(req.preferredDate());
            slots.add(slot(date, "09:00", req.triageCategory()));
            slots.add(slot(date, "11:30", req.triageCategory()));
            if (!"MORNING".equalsIgnoreCase(req.preference())) {
                slots.add(slot(date, "14:00", req.triageCategory()));
            }
        }

        Map<String, Object> body = new LinkedHashMap<>();
        body.put("patientRef", req.patientRef());
        body.put("hasAvailableSlots", !slots.isEmpty());
        body.put("slotCount", slots.size());
        body.put("availableSlots", slots);
        body.put("synthetic", true);
        return ResponseEntity.ok(body);
    }

    /**
     * Simulated booking endpoint called by the "Book appointment (REST)"
     * connector once a slot is available. Also honours the failure flag so
     * the same incident drill works on the booking step.
     */
    @PostMapping("/book")
    public ResponseEntity<Map<String, Object>> book(@RequestBody BookRequest req) {
        if (state.isFailureEnabled()) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "SCHEDULING_SERVICE_UNAVAILABLE",
                            "message", "Simulated scheduling outage (failure flag enabled)."));
        }

        List<Map<String, Object>> slots = new ArrayList<>();
        LocalDate date = parseSafe(req.preferredDate());
        slots.add(slot(date, "09:00", "Routine"));
        slots.add(slot(date, "11:30", "Routine"));
        slots.add(slot(date, "14:00", "Routine"));

        int idx = req.slotIndex() == null ? 0 : req.slotIndex();
        if (idx >= slots.size()) {
            idx = 0;
        }
        Map<String, Object> chosen = new LinkedHashMap<>(slots.get(idx));
        chosen.put("bookingStatus", "BOOKED");

        Map<String, Object> body = new LinkedHashMap<>();
        body.put("patientRef", req.patientRef());
        body.put("bookedSlot", chosen);
        body.put("bookingStatus", "BOOKED");
        body.put("synthetic", true);
        return ResponseEntity.ok(body);
    }

    private Map<String, Object> slot(LocalDate date, String time, String triage) {
        Map<String, Object> s = new LinkedHashMap<>();
        s.put("date", date.toString());
        s.put("time", time);
        s.put("triageCategory", triage);
        s.put("bookingStatus", "OPEN");
        return s;
    }

    private LocalDate parseSafe(String iso) {
        try {
            return LocalDate.parse(iso);
        } catch (Exception e) {
            return LocalDate.now().plusDays(1);
        }
    }
}
