# Cross-Lab Process Variable Dictionary

A single reference of every process variable across Labs 1–3, grouped by who writes it. Per-lab details (types, defaults, example values) live in each lab's `README.md`; use this page as the index.

## Written at start (Tasklist start form)

| Variable | Labs | Type | Example | Meaning |
|----------|------|------|---------|---------|
| `applicantId` | 1 | String | `APP-1001` | Synthetic applicant reference |
| `requestedLoanAmount` | 1 | Number | `240000` | Loan requested |
| `monthlyIncome` | 1 | Number | `8000` | Applicant income |
| `creditScore` | 1 | Number | `780` | Synthetic score (300–850) |
| `customerRef` | 2 | String | `ORD-2001` | Synthetic order/customer ref |
| `productId` | 2 | String | `P-1002` | Catalogue product id |
| `quantity` | 2 | Number | `2` | Units |
| `deliveryPreference` | 2 | String | `EXPRESS` | Delivery preference |
| `customerCategory` | 2 | String | `GOLD` | SILVER / GOLD / PLATINUM |
| `paymentToken` | 2 | String | `synth-8842` | Synthetic token (`...0000` = decline) |
| `patientRef` | 3 | String | `PAT-3001` | Synthetic patient ref |
| `preferredDate` | 3 | String (ISO) | `2026-11-15` | Requested date |
| `appointmentPreference` | 3 | String | `MORNING` | MORNING / AFTERNOON / FULL / ANY |
| `symptomsSummary` | 3 | String | `"synthetic note"` | Free-text symptom note |
| `vitalConcern` | 3 | Boolean | `false` | Predefined urgency indicator |
| `severityScore` | 3 | Number | `5` | Predefined urgency indicator (0–10) |

## Written by external workers

| Variable | Labs | Type | Set by | Meaning |
|----------|------|------|--------|---------|
| `applicantValid` | 1 | Boolean | `LoanWorker` | Basic validation passed |
| `validationError` | 1 | String\|null | `LoanWorker` | Reason if invalid |
| `debtToIncomePct` | 1 | Number | `LoanWorker` | Loan ÷ (income × 60), % |
| `orderValid` | 2 | Boolean | `OrderWorker` | Known product, positive qty |
| `stockAvailable` | 2 | Boolean | `OrderWorker` | Catalogue stock ≥ qty |
| `stockOnHand` | 2 | Number | `OrderWorker` | Units available |
| `unitPrice` / `orderTotal` | 2 | Number | `OrderWorker` | Priced values |
| `registrationValid` | 3 | Boolean | `HospitalWorker` | Ref + date present |
| `hasAvailableSlots` | 3 | Boolean | `HospitalWorker` (REST) | Slots exist |
| `slotCount` | 3 | Number | `HospitalWorker` | Slots found |
| `needsManualIntervention` | 3 | Boolean | `HospitalWorker` | High-severity / vital flag |

## Written by DMN decision tasks (named after the DMN output)

| Variable | Labs | Value set | Set by |
|----------|------|-----------|--------|
| `decision` | 1 | `Approved` / `Manual Review` / `Rejected` | `loan-eligibility` |
| `priority` | 2 | `HIGH` / `NORMAL` / `LOW` | `order-priority` |
| `triageCategory` | 3 | `Routine` / `Priority Review` / `Urgent Assessment` | `patient-triage` |

## Written by REST connectors (out-of-the-box)

| Variable | Labs | Type | Meaning |
|----------|------|------|---------|
| `creditAssessment` | 1 | String | `GOOD` / `FAIR` / `POOR` |
| `creditApproved` / `creditDeclined` / `creditNeedsReview` | 1 | Boolean | Fast-path signals; `creditDeclined` drives the gateway |
| `disbursementRef` | 1 | String | Synthetic disbursement ref |
| `paymentStatus` / `paymentDeclined` / `paymentRef` | 2 | String / Boolean / String | `CAPTURED` / `DECLINED` + reference |
| `orderStatus` / `fulfilmentRef` | 2 | String | `FULFILLED` + reference |
| `availableSlots` | 3 | Array | Slot objects from the mock API |
| `bookingStatus` / `bookedSlot` | 3 | String / Object | Synthetic booking confirmation |

## Written by humans in Tasklist

| Variable | Labs | Type | Meaning |
|----------|------|------|---------|
| `reviewDecision` | 1 | String | `approved` / `rejected` on the loan manual-review task |
| `confirmed` | 2 | Boolean | High-value order verification outcome |
| *(triage review tasks complete with no mandatory variable)* | 3 | — | Optional note; completion advances the instance |

> **Rule of thumb:** a gateway condition can only reference a variable that has been *written earlier in the path*. That's why workers publish their results as variables before the DMN and gateways read them.
