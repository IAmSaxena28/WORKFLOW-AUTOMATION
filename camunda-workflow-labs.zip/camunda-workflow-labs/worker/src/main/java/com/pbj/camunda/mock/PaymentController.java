package com.pbj.camunda.mock;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * LAB 2 — simulated payment-gateway API.
 *
 * Deterministic outcome so the test cases are reproducible:
 *   - a payment token ending in "0000" simulates a card-decline,
 *   - the shared failure flag simulates a gateway outage.
 */
@RestController
@RequestMapping("/mock/payment")
public class PaymentController {

    private final MockState state;

    public PaymentController(MockState state) {
        this.state = state;
    }

    public record ChargeRequest(
            String orderRef,
            Double amount,
            String paymentToken,   // synthetic; "****0000" triggers a decline
            String customerCategory
    ) {}

    @PostMapping("/charge")
    public ResponseEntity<Map<String, Object>> charge(@RequestBody ChargeRequest req) {
        if (state.isFailureEnabled()) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "PAYMENT_GATEWAY_UNAVAILABLE",
                            "message", "Simulated payment gateway outage (failure flag enabled)."));
        }

        boolean declined = req.paymentToken() != null
                && req.paymentToken().trim().endsWith("0000");

        Map<String, Object> body = new LinkedHashMap<>();
        body.put("orderRef", req.orderRef());
        body.put("amount", req.amount());
        body.put("paymentStatus", declined ? "DECLINED" : "CAPTURED");
        body.put("paymentRef", declined ? null : "PAY-" + Math.abs(req.orderRef().hashCode() % 100000));
        body.put("declinedReason", declined ? "insufficient_funds" : null);
        body.put("synthetic", true);
        return ResponseEntity.ok(body);
    }
}
