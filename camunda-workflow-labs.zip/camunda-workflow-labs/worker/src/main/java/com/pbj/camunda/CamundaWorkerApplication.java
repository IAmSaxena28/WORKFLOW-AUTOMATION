package com.pbj.camunda;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Single Spring Boot app that runs, in one process:
 *
 *  - the external job workers for all three labs
 *    (see com.pbj.camunda.workers.*), and
 *  - the mock REST services the BPMN REST Connector calls
 *    (see com.pbj.camunda.mock.*).
 *
 * Running this one app therefore powers Labs 1-3 end to end.
 */
@SpringBootApplication
public class CamundaWorkerApplication {

    public static void main(String[] args) {
        SpringApplication.run(CamundaWorkerApplication.class, args);
    }
}
